from django.contrib import admin
from services.models import *

# Register your models here.
admin.site.register(Service)
admin.site.register(Statistics)
admin.site.register(Skills)